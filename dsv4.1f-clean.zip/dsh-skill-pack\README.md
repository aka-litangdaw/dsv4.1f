# DeepSeek Harness Evidence Skill Pack

这是一个可复制/归档的 DeepSeek Harness skill pack，包含两个本地 skill：

- `evidence-grounded-answer-loop`：证据追踪、可比性分级、完成门、代码检查状态和科学数据审计。
- `deepseek-v41-flash-adapter`：DeepSeek-V4.1-Flash-1017 的 thinking、tool call、JSON、vision、长上下文和 smoke-test 适配。

## 安装位置

DeepSeek Harness 的用户级 skill 根目录：

| 平台 | 路径 |
| --- | --- |
| Windows | `%USERPROFILE%\.dsh\skills\` |
| Linux / macOS | `~/.dsh/skills/` |

本仓库是便携副本，把两个目录整体复制到上面的 skill 根目录即可。

## 手动安装

PowerShell（Windows）：

```powershell
Copy-Item -Recurse -Force .\evidence-grounded-answer-loop "$env:USERPROFILE\.dsh\skills\"
Copy-Item -Recurse -Force .\deepseek-v41-flash-adapter  "$env:USERPROFILE\.dsh\skills\"
```

bash（Linux / macOS）：

```bash
mkdir -p ~/.dsh/skills
cp -R ./evidence-grounded-answer-loop ./deepseek-v41-flash-adapter ~/.dsh/skills/
```

安装后新建 Harness 会话，使 skill catalog 重新扫描。API key 不包含在此仓库中；请在 Harness 的 `Settings → Models` 中配置。

## 验证边界

- 文件和 frontmatter 可直接安装。
- 需要 Harness 启用 `dsh-skill-filesystem` 与 `dsh-tool-skill` 才能被 catalog 扫描到。
- 实际 API smoke test 仍需要自己的 DeepSeek API key；密钥不保存到本仓库。

## License

未附许可证时默认保留全部权利。如需他人复用，请自行添加 `LICENSE`（例如 MIT / CC BY 4.0）。
